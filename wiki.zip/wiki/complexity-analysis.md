---
title: Complexity Analysis
tags: [algorithms, complexity, big-o, master-theorem]
---

# Complexity Analysis

## Asymptotic Analysis

It is often useful to estimate how long an algorithm runs. You could simply implement it and measure, but that creates several problems:

- Runtime always differs across machines.
- The real input data may not be available in advance.
- Some algorithms require hours or days to run.
- If there are several candidate algorithms, you want to predict which is faster before implementing.

As a first approximation, we count the number of **operations** in the algorithm. Elementary operations include:

- Arithmetic: `+`, `-`, `*`, `/`
- Comparisons: `<`, `>`, `<=`, `>=`, `==`, `!=`
- Assignments: `a[0] = 3`

### Big-O Notation

To simplify analysis, **O-notation** (asymptotic complexity) is used instead of exact operation counts.

**Definition.** A function `g(n) = O(f(n))` if there exist constants `c` and `n0` such that `g(n) < c * f(n)` for all `n >= n0`.

**Examples:**
- `n/3 = O(n)`
- `n(n-1)(n-2)/6 = O(n^3)`
- `1 + 2 + 3 + ... + n = O(n^2)`
- `log2(n) + 3 = O(log n)`
- `179 = O(1)`
- `10^100 = O(1)`

**Key insight:** O-notation ignores constant factors and additive constants. An `O(n^2)` algorithm might run in `n^2`, `n^2 + 3`, `n(n-1)/2`, or `1000*n^2 + 1` steps — what matters is the growth rate.

If an algorithm is `O(n^2)`, then increasing `n` by 10x increases runtime by approximately 100x.

### Complexity of Common Sorting Algorithms

| Algorithm      | Complexity |
|----------------|------------|
| [Bubble sort](sorting-algorithms.md)    | O(n^2)     |
| [Selection sort](sorting-algorithms.md) | O(n^2)     |
| [Insertion sort](sorting-algorithms.md) | O(n^2)     |
| [Counting sort](sorting-algorithms.md)  | O(n + m)   |

The first three are called **quadratic** sorts. Counting sort can be much faster — linear `O(n)` when `m <= n`.

---

## Master Theorem

The Master Theorem gives the asymptotic complexity of **divide-and-conquer** recurrences where a problem of size `n` is divided into `a` subproblems of size `n/b`, with a merge step costing `Theta(n^c)`.

**Theorem.** Given the recurrence:

```
T(n) = a*T(n/b) + Theta(n^c),  n > n0
T(n) = Theta(1),                n <= n0
```

Then:

- **Case A:** If `c > log_b(a)`, then `T(n) = Theta(n^c)`
- **Case B:** If `c = log_b(a)`, then `T(n) = Theta(n^c * log n)`
- **Case C:** If `c < log_b(a)`, then `T(n) = Theta(n^(log_b a))`

### Proof via Recursion Tree

The recursion tree has `log_b(n)` levels. At level `k` there are `a^k` nodes, each costing `(n/b^k)^c` operations. Summing all levels:

```
T(n) = sum_{k=0}^{log_b n}  a^k * (n/b^k)^c  =  n^c * sum_{k=0}^{log_b n} (a/b^c)^k
```

- **Case A:** `a/b^c < 1` — geometric series converges to a constant — `T(n) = Theta(n^c)`
- **Case B:** `a/b^c = 1` — each term equals 1 — `T(n) = Theta(n^c * log n)`
- **Case C:** `a/b^c > 1` — sum dominated by the largest term — `T(n) = Theta(n^(log_b a))`

### Limitation

The theorem does not cover all merge costs. For example, merge costing `Theta(n log n)` with binary split gives:

```
sum_{k=0}^{log n} n * log(n/2^k) = n * sum k = Theta(n log^2 n)
```

This recurrence does not fit the theorem, so only loose bounds can be derived.

---

## See Also

- [Sorting Algorithms](sorting-algorithms.md) — complexity of common sorts analyzed here
- [Binary Search](binary-search.md) — classic O(log n) algorithm
- [Mathematics](mathematics.md) — binary exponentiation and sieve complexities
- [Data Structures](data-structures.md) — O(log n) structures like Fenwick and segment trees

---

*Source: ru.algorithmica.org — CC BY-SA 4.0*
