---
title: Mathematics
tags: [math, binary-exponentiation, gcd, euclid, primes, sieve, modular-arithmetic]
---

# Mathematics

---

## Binary Exponentiation

Computes `a^n` in **O(log n)** multiplications instead of O(n).

### Core Idea

For even `n`:  `a^n = (a^(n/2))^2`
For odd `n`:   `a^n = a^(n-1) * a`

This halves the problem size every two steps, giving at most `2 log₂ n` multiplications total.

### Iterative Implementation

```cpp
int binpow(int a, int n) {
    int res = 1;
    while (n != 0) {
        if (n & 1)
            res = res * a;
        a = a * a;
        n >>= 1;
    }
    return res;
}
```

Iterates through the **binary representation of `n`**: when bit `k` is 1, multiply result by `a^(2^k)`.

**Example:** `a^42 = a^(32+8+2) = a^32 * a^8 * a^2`

Note: C++'s built-in `pow()` is for floating-point and is imprecise for integers — always use a custom `binpow`.

### Modular Exponentiation

```cpp
const int mod = 1e9 + 7;

long long binpow(long long a, int n) {
    long long res = 1;
    while (n != 0) {
        if (n & 1)
            res = res * a % mod;
        a = a * a % mod;
        n >>= 1;
    }
    return res;
}
```

### Generalizations

Binary exponentiation applies to **any associative operation** `(a * b) * c = a * (b * c)`:
- Modular arithmetic (shown above)
- **Matrix exponentiation** — compute `A^n` for a matrix `A` in O(k³ log n) where k is the matrix size
- XOR, GCD, etc.

### Geometric Series

To compute `S = 1 + a + a^2 + ... + a^(n-1)` when direct division isn't possible (e.g. modular context without guaranteed inverse):

```
f(a, n) = (1 + a^(n/2)) * f(a, n/2)   for even n
```

Maintain both the power `a^k` and the partial sum simultaneously during the recursion.

---

## Euclidean Algorithm (GCD)

The **greatest common divisor (GCD)** of two non-negative integers `a` and `b` is the largest integer dividing both.

```
gcd(a, 0) = a
gcd(a, b) = gcd(b, a mod b)    for b > 0
```

**Correctness:** Any common divisor of `a` and `b` also divides `a mod b = a - floor(a/b)*b`.

### Implementation

```cpp
int gcd(int a, int b) {
    while (b > 0) {
        a %= b;
        swap(a, b);
    }
    return a;
}
```

C++ (C++17) has a built-in `std::gcd` — use it, but be careful with negative numbers and the `(0, 0)` case.

### Complexity

Every two steps, the smaller number decreases by at least half → `O(log min(a, b))`. See [complexity analysis](complexity-analysis.md) for more on logarithmic algorithms.

The **worst case** inputs are consecutive Fibonacci numbers (they are the hardest for Euclidean algorithm). For a group of `n` numbers in `[1, A]`: computing GCD takes `O(n + log A)` total, not `O(n log A)`.

### Extended Euclidean Algorithm

Finds integers `x`, `y` such that `a*x + b*y = gcd(a, b)` (Bezout's identity). Used for:
- Computing modular inverses
- Solving linear Diophantine equations

---

## Modular Arithmetic

When working with large numbers in competitive programming, results are often taken modulo a prime `p` (typically `10^9 + 7`).

### Modular Inverse

The **modular inverse** of `a` modulo prime `p` is a number `a^(-1)` such that `a * a^(-1) ≡ 1 (mod p)`.

By Fermat's Little Theorem: `a^(-1) ≡ a^(p-2) (mod p)` when `p` is prime.

Use `binpow(a, p - 2, mod)` to compute it. This enables **modular division**: `a / b mod p = a * binpow(b, p-2, mod) % mod`.

---

## Sieve of Eratosthenes

**Problem.** Find all primes from 1 to n.

**Definition.** A positive integer is **prime** if it has exactly two distinct positive divisors: 1 and itself (note: 1 is not prime).

### Algorithm

Mark all multiples of each prime as composite:

```cpp
vector<bool> sieve(int n) {
    vector<bool> is_prime(n + 1, true);
    is_prime[0] = is_prime[1] = false;
    for (int i = 2; i <= n; i++)
        if (is_prime[i])
            for (int j = 2 * i; j <= n; j += i)
                is_prime[j] = false;
    return is_prime;
}
```

**Performance note:** Use `vector<char>` instead of `vector<bool>` if speed matters — `bool` packs bits and requires extra bit operations to index.

### Complexity

```
sum_{k=2}^{n} n/k  =  n * (1/2 + 1/3 + ... + 1/n)  =  O(n log n)
```

More precisely, since we only iterate over primes (density ~`1/ln n`):

```
O(n log log n)
```

### Linear Sieve

Mark each composite number exactly **once** — by its smallest prime divisor `d[k]`. This achieves `O(n)` time at the cost of more memory (stores `int` per number vs. 1 bit).

```cpp
const int n = 1e6;
int d[n + 1];
vector<int> p; // list of primes found so far

for (int k = 2; k <= n; k++) {
    if (d[k] == 0) {
        d[k] = k;
        p.push_back(k);
    }
    for (int x : p) {
        if (x > d[k] || (long long)x * k > n) break;
        d[k * x] = x;
    }
}
```

### Application: Fast Factorization

With the `d[]` array, factorize any number `k` in `O(log k)`:

```cpp
// factor k using the d[] array from the linear sieve
while (k > 1) {
    cout << d[k] << " ";
    k /= d[k];
}
```

The linear sieve is valuable precisely for this `d[]` array — it lets you precompute factorizations of all numbers efficiently.

---

## Matrix Exponentiation

Raising an `m x m` matrix to the power `n` takes `O(m³ log n)` using binary exponentiation.

**Common applications:**
- Computing the `n`-th Fibonacci number in `O(log n)` — see also [dynamic programming](dynamic-programming.md) for the DP approach:

```
[F(n+1)]   [1 1]^n   [F(1)]
[F(n)  ] = [1 0]   * [F(0)]
```

- Counting paths of length `n` in a [graph](graph-algorithms.md)
- Solving linear recurrences in `O(log n)` per query

---

## See Also

- [Dynamic Programming](dynamic-programming.md) — modular arithmetic in DP, matrix exponentiation for recurrences
- [Graph Algorithms](graph-algorithms.md) — binary lifting (LCA) uses binary exponentiation; path counting via matrix power
- [Data Structures](data-structures.md) — Fenwick trees use modular operations; prefix XOR
- [Complexity Analysis](complexity-analysis.md) — O(log n) analysis of binary exponentiation and GCD

---

*Source: ru.algorithmica.org — CC BY-SA 4.0*
