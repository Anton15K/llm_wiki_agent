---
title: Strings and Geometry
tags: [strings, prefix-function, kmp, hashing, trie, suffix-array, geometry, convex-hull]
---

# Strings and Geometry

---

## String Searching

### Prefix Function (KMP)

**Definition.** The **prefix function** of string `s` is an array `p` where `p[i]` is the length of the longest proper prefix of `s[0..i]` that is also a suffix.

**Example:** For `"aataataa"`, the prefix function is `[0, 1, 0, 1, 2, 3, 4, 5]` — the longest prefix that is also a suffix of the full string is `"aataa"` (length 5).

#### Naive O(n³)

```cpp
vector<int> slow_prefix_function(string s) {
    int n = s.size();
    vector<int> p(n, 0);
    for (int i = 1; i < n; i++)
        for (int len = 1; len <= i; len++)
            if (s.substr(0, len) == s.substr(i - len + 1, len))
                p[i] = len;
    return p;
}
```

#### Efficient O(n)

Key observation: `p[i+1] <= p[i] + 1`. When the extension fails, fall back through the chain `p[cur-1]`:

```cpp
vector<int> prefix_function(string s) {
    int n = s.size();
    vector<int> p(n, 0);
    for (int i = 1; i < n; i++) {
        int cur = p[i - 1];
        while (s[i] != s[cur] && cur > 0)
            cur = p[cur - 1];
        if (s[i] == s[cur])
            p[i] = cur + 1;
    }
    return p;
}
```

**Complexity:** Each step the `while` decreases `cur` by at least 1, but `p[i]` increases by at most 1 per outer iteration → `O(n)` total. See [complexity analysis](complexity-analysis.md) for amortized reasoning.

#### Knuth-Morris-Pratt (KMP) Substring Search

To find all occurrences of pattern `s` in text `t`:
1. Compute prefix function of `s + "#" + t` (separator `#` not in either string)
2. Positions where `p[i] == len(s)` mark ends of occurrences

```
"choose#choose life. choose a job..."
 0000000123456000000012345600000000...
                ^                ^
               end of match    end of match
```

---

### Z-function

**Definition.** The **Z-function** of string `s` is an array `z` where `z[i]` is the length of the longest substring starting at `s[i]` that is also a prefix of `s`.

By convention `z[0] = 0`. Computed in `O(n)` using a sliding window `[l, r]` of the current Z-box.

**Substring search with Z-function:** compute Z of `s + "#" + t`; positions where `z[i] == len(s)` are match starts.

---

### Polynomial Hashing

Map strings to integers to compare them in `O(1)` after `O(n)` preprocessing.

**Formula:** `hash(s[l..r]) = s[l]*p^0 + s[l+1]*p^1 + ... + s[r]*p^(r-l) mod M`

Using prefix hashes (similar to [prefix sums](data-structures.md)):
```cpp
const long long P = 31, MOD = 1e9 + 7;
vector<long long> h(n+1, 0), pw(n+1, 1);

for (int i = 0; i < n; i++) {
    h[i+1] = (h[i] + (s[i] - 'a' + 1) * pw[i]) % MOD;
    pw[i+1] = pw[i] * P % MOD;
}

// hash of s[l..r]:
long long get_hash(int l, int r) {
    return (h[r+1] - h[l] + MOD) % MOD * inv_pw[l] % MOD;
}
```

**Warning:** Single-hash collisions occur with probability `~1/MOD`. Use double hashing (two different moduli) for reliability. See [modular arithmetic](mathematics.md) for computing modular inverses.

**Applications:** Substring comparison in `O(1)`, rolling hash for pattern matching, isomorphism checks.

---

## String Structures

### Trie (Prefix Tree)

A trie stores a set of strings as a tree where each edge represents a character. All strings sharing a common prefix share the corresponding path from the root.

**Operations:** Insert, search, and prefix queries — all `O(|s|)`.

**Applications:** Autocomplete, dictionary lookup, longest common prefix queries.

### Aho-Corasick Automaton

Extends a trie with **failure links** (similar to KMP's prefix function). Enables simultaneous search for all patterns from a dictionary in a text — `O(|text| + sum of |patterns| + number of matches)`.

**Build:** Construct trie, then compute failure links via BFS.

### Suffix Array

A **suffix array** is a sorted array of all suffixes of a string. Construction in `O(n log n)` using doubling (sort by pairs of characters, then pairs of pairs, etc.).

Combined with the **LCP array** (longest common prefix between adjacent suffixes), it enables:
- Pattern matching in `O(m log n)` (via [binary search](binary-search.md))
- Counting distinct substrings
- Longest repeated substring
- Many other string queries

---

## Geometry Basics

### Points and Vectors

A point `(x, y)` in 2D. A vector is the difference between two points.

**Dot product:** `a · b = ax*bx + ay*by = |a||b|cos(θ)`
- `> 0` → acute angle, `= 0` → perpendicular, `< 0` → obtuse angle

**Cross product (2D):** `a × b = ax*by - ay*bx = |a||b|sin(θ)`
- `> 0` → `b` is counterclockwise from `a`
- `< 0` → `b` is clockwise from `a`
- `= 0` → collinear
- `|a × b|` = area of parallelogram spanned by `a` and `b`

### Lines and Segments

- Point-on-segment test via cross product (collinearity) and dot product (between endpoints)
- Segment intersection: test if endpoints of each segment lie on opposite sides of the other
- Line equation from two points: `(y2-y1)*x - (x2-x1)*y + (x2-x1)*y1 - (y2-y1)*x1 = 0`

### Polygon Area (Shoelace Formula)

```
Area = |sum_{i=0}^{n-1} (x[i] * y[(i+1)%n] - x[(i+1)%n] * y[i])| / 2
```

This equals half the absolute value of the sum of cross products of consecutive edge vectors.

---

## Convex Hulls

The **convex hull** of a point set is the smallest convex polygon containing all points.

### Graham's Scan — O(n log n)

1. Pick the lowest point as pivot
2. Sort all other points by polar angle around pivot
3. Sweep through sorted points, maintaining a stack; pop while the last three points make a non-left turn

```
O(n log n) for sorting, O(n) for the sweep
```

### Jarvis March (Gift Wrapping) — O(nh)

Start from the leftmost point, repeatedly find the next point making the smallest counterclockwise angle. `h` = hull size. Optimal when `h` is small.

### Chan's Algorithm — O(n log h)

Combines Graham's scan and Jarvis march to achieve the optimal `O(n log h)` complexity.

### Applications of Convex Hulls

- **[Convex Hull Trick](dynamic-programming.md)** in DP (maintaining lower/upper envelope of lines)
- Rotating calipers for diameter, width, closest pair on hull
- Half-plane intersection

---

## String Structures Summary

| Structure       | Build       | Query            | Use case                              |
|----------------|-------------|------------------|---------------------------------------|
| Prefix function | O(n)        | O(n) search      | Single-pattern substring search (KMP) |
| Z-function      | O(n)        | O(n) search      | Single-pattern search, alternative to KMP |
| Polynomial hash | O(n)        | O(1) per query   | Substring comparison, rolling hash   |
| Trie            | O(sum |s|)  | O(|s|) per query | Prefix queries, dictionary            |
| Aho-Corasick    | O(sum |s|)  | O(|text|)        | Multi-pattern search                  |
| Suffix array    | O(n log n)  | O(m log n)       | All-substring queries, LCP            |

---

## See Also

- [Dynamic Programming](dynamic-programming.md) — convex hull trick uses geometric convex hull ideas
- [Binary Search](binary-search.md) — used in suffix array pattern matching
- [Data Structures](data-structures.md) — prefix hashing is analogous to prefix sums
- [Mathematics](mathematics.md) — modular inverses for polynomial hashing
- [Sorting Algorithms](sorting-algorithms.md) — sorting by polar angle in convex hull algorithms

---

*Source: ru.algorithmica.org — CC BY-SA 4.0*
