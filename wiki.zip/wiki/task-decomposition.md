---
title: Task Decomposition
tags: [algorithms, scanline, mo, sqrt, meet-in-the-middle]
---

# Task Decomposition

General techniques for solving problems by breaking them into simpler subproblems.

---

## Scanline (Sweep Line)

The **scanline** method consists of sorting points on a number line (or abstract "events") by some criterion, then sweeping through them in order. It is often used for data structure problems where all queries are known in advance, and in geometry for computing unions of shapes.

### Problem: Point Covered by the Most Segments

**Task:** Given `n` segments `[l_i, r_i]` on a line, find any point covered by the maximum number of segments.

**Naive O(n^2):** Check all endpoints as candidate points.

**Optimal O(n log n) — scanline:**

Sort all segment endpoints as events (start = +1, end = -1). Walk left to right maintaining a counter `cnt`. Note: at equal coordinates, process starts before ends so boundary segments are counted correctly.

```cpp
struct event {
    int x, type; // type: +1 = start, -1 = end
};

int scanline(vector<pair<int, int>> segments) {
    vector<event> events;

    for (auto [l, r] : segments) {
        events.push_back({l, 1});
        events.push_back({r, -1});
    }

    sort(events.begin(), events.end(), [](event a, event b) {
        return (a.x < b.x || (a.x == b.x && a.type > b.type));
    });

    int cnt = 0, res = 0;

    for (event e : events) {
        cnt += e.type;
        res = max(res, cnt);
    }

    return res;
}
```

### Problem: Length of Union of Segments

Walk the same sorted events but now accumulate the length of intervals where `cnt > 0`:

```cpp
int cnt = 0, res = 0, prev = -inf;

for (event e : events) {
    if (prev != -inf && cnt > 0)
        res += e.x - prev; // interval [prev, e.x] is covered
    cnt += e.type;
    prev = e.x;
}
```

**Complexity:** O(n log n)

### Problem: How Many Segments Cover Each Query Point

For `q` offline query points, add them as type-0 events alongside segment start/end events. Sort all events together (starts first, then queries, then ends at equal coordinates). Walk left to right and record `cnt` when a query event is reached.

```cpp
struct event {
    int x, type, idx;
};

void scanline(vector<pair<int, int>> segments, vector<int> queries) {
    int q = (int) queries.size();
    vector<int> ans(q);
    vector<event> events;

    for (auto [l, r] : segments) {
        events.push_back({l, 1});
        events.push_back({r, -1});
    }
    for (int i = 0; i < q; i++)
        events.push_back({queries[i], 0, i});

    sort(events.begin(), events.end(), [](event a, event b) {
        return (a.x < b.x || (a.x == b.x && a.type > b.type));
    });

    int cnt = 0;
    for (event e : events) {
        cnt += e.type;
        if (e.type == 0)
            ans[e.idx] = cnt;
    }
}
```

**Complexity:** O((n + q) log(n + q))

### 2D Scanline: Rectangle Sum / Area of Union

For 2D problems (e.g., count points in rectangles, area of union of rectangles):
- Decompose each rectangle query into two prefix queries.
- Use a [segment tree](data-structures.md) on the y-axis while sweeping through x-events.
- Complexity: **O(n log n)** with [coordinate compression](coordinate-compression.md).

---

## Mo's Algorithm

Mo's algorithm answers offline range queries efficiently by grouping and sorting them spatially.

**Example task:** Array of `n` integers from 1 to n. Answer `q` offline queries: "how many distinct values are in range `[l_i, r_i]`?"

### Algorithm

Group queries into blocks of size `c ≈ sqrt(n)` by their left boundary. Within each block, sort queries by right boundary.

```cpp
struct query { int l, r, idx; };

int a[maxn], ans[maxq];
int cnt[maxn], res;

void add(int k) {
    if (cnt[a[k]]++ == 0) res++;
}

void del(int k) {
    if (--cnt[a[k]] == 0) res--;
}
```

For each block, sweep the right boundary forward (monotonically), and adjust the left boundary freely:

```cpp
for (int i = 0; i < c; i++) {
    int l = i * c, r = i * c - 1;
    memset(cnt, 0, sizeof cnt);
    res = 0;
    for (query q : b[i]) {
        while (r < q.r) add(++r);
        while (l < q.l) del(l++);
        while (l > q.l) add(--l);
        ans[q.idx] = res;
    }
}
```

**Why it's fast:**
- Right boundary moves a total of O(n) per block → O(n * sqrt(n)) total.
- Left boundary moves at most O(sqrt(n)) per query → O(q * sqrt(n)) total.

**Total complexity:** O((n + q) * sqrt(n)). See [complexity analysis](complexity-analysis.md) for more on asymptotic notation.

### Variations

- **Most frequent element:** Maintain `cnt` array and relax `res` only on additions; restore `res` from a backup before left-boundary rollbacks.
- **k-th order statistic:** Use a sqrt-decomposed frequency array as internal structure — O(sqrt(n)) per update and query.
- **Mo on trees:** Apply Euler tour to reduce tree path queries to array range queries; include only elements appearing exactly once in the range.
- **3D Mo (with updates):** Add a time dimension `t` (number of updates before the query), sort by `(t/n^(2/3), l/n^(2/3), r)`. Complexity: O(n^(5/3)).

---

## State Rollback / Sqrt on Queries

When a static data structure is fast to build but slow to update, use sqrt decomposition on queries:

- Rebuild the structure every `sqrt(q)` queries in O(n).
- For each sum/read query, use the last checkpoint + O(sqrt(q)) corrections from the buffer.

**Complexity:** O((n + q) * sqrt(q))

### Powers-of-Two Structure

Maintain O(log n) structures of sizes that are distinct powers of two. When adding an element:
1. Create a new structure of size 1.
2. If a size-1 structure exists, merge → size 2. Repeat until no conflict.

This gives amortized O(n log n) build time. Queries are answered by checking all O(log n) structures.

---

## Meet in the Middle

Splits a brute-force search in half, computing partial solutions for each half and combining them. Reduces exponential complexity from `O(2^n)` to `O(2^(n/2))`.

**Example:** Subset sum — enumerate all sums of the left half, sort them, then for each sum of the right half use [binary search](binary-search.md) to find a matching complement.

---

## See Also

- [Data Structures](data-structures.md) — segment trees and Fenwick trees used in 2D scanline
- [Coordinate Compression](coordinate-compression.md) — often needed for scanline on large coordinate ranges
- [Binary Search](binary-search.md) — used in meet-in-the-middle and many scanline variants
- [Sorting Algorithms](sorting-algorithms.md) — scanline relies on sorting events

---

*Source: ru.algorithmica.org — CC BY-SA 4.0*
