---
title: Data Structures
tags: [data-structures, prefix-sums, fenwick-tree, dsu, segment-tree]
---

# Data Structures

---

## Prefix Sums

**Definition.** The prefix sum array of `[a0, a1, ..., a(n-1)]` is `[s0, s1, ..., sn]` defined as:

```
s0 = 0
s1 = a0
s2 = a0 + a1
...
sk = a0 + a1 + ... + a(k-1)
```

Note: `sk` equals the sum of the **first k elements** (not including `ak`). The length of `s` is one greater than `a`, and `s0` is always 0.

### Building in O(n)

```cpp
int s[n + 1];
s[0] = 0;
for (int i = 0; i < n; i++)
    s[i + 1] = s[i] + a[i];
```

### Range Sum Query in O(1)

**Problem.** Answer `m` queries "sum from index `l` to `r`".

Using the identity:

```
a[l] + a[l+1] + ... + a[r-1]  =  s[r] - s[l]
```

Just subtract two precomputed prefix sums.

### Other Invertible Operations

Prefix sums work for any invertible operation:
- **XOR:** `a[l] ^ ... ^ a[r-1]  =  s[r] ^ s[l]`
- **Modular addition/multiplication**

Operations like **min** and **max** are not invertible and cannot use this trick (use sparse tables or segment trees instead).

### Practice Problems

1. Given an array, find a subarray with a target sum — `O(n)`.
2. Given two arrays, find a subarray where sums from both arrays are equal.
3. Given a multiset of `n` integers, find a subset whose sum is divisible by `n`.

---

## Fenwick Tree (Binary Indexed Tree)

A **Fenwick tree** (BIT) is a data structure that replaces segment trees in many problems while being 3–4× faster, using minimal memory (same as the array), easier to code, and easily generalized to multiple dimensions.

### Definition

Given array `a[1..n]`, the Fenwick tree is array `t[1..n]` where:

```
t[i] = sum of a[F(i)..i]
```

with `F(x) = x - (x & -x) + 1` (removes the lowest set bit of x and adds 1).

### Key Insight: x & -x

`x & -x` returns the **lowest set bit** of `x`. This works because in two's complement, `-x = ~x + 1`, so the lowest bit of `x` and `-x` are both 1, and all higher differing bits cancel out.

**Example:** `+90 = 1011010₂`, `-90 = 0100110₂`, `90 & -90 = 0000010₂` ✓

### Implementation (1-indexed)

```cpp
int t[maxn];

// prefix sum [1..r]
int sum(int r) {
    int res = 0;
    for (; r > 0; r -= r & -r)
        res += t[r];
    return res;
}

// range sum [l..r]
int sum(int l, int r) {
    return sum(r) - sum(l - 1);
}

// add x to position k
void add(int k, int x) {
    for (; k <= n; k += k & -k)
        t[k] += x;
}
```

Notice the elegant symmetry: `sum` uses `r -= r & -r` (removes lowest bit), `add` uses `k += k & -k` (moves to parent). Both run in `O(log n)`.

### 2D Fenwick Tree

Just nest the loops — add one extra dimension:

```cpp
int sum(int r1, int r2) {
    int res = 0;
    for (int i = r1; i > 0; i -= i & -i)
        for (int j = r2; j > 0; j -= j & -j)
            res += t[i][j];
    return res;
}
```

For a 2D range query, use inclusion-exclusion (4 prefix queries).

### Binary Search on Prefix Sums

Find the smallest index where the prefix sum exceeds `s`:

```cpp
int lower_bound(int s) {
    int k = 0;
    for (int l = logn; l >= 0; l--) {
        if (k + (1 << l) <= n && t[k + (1 << l)] < s) {
            k += (1 << l);
            s -= t[k];
        }
    }
    return k;
}
```

This is essentially a descent through the implicit binary tree structure. See also [binary search](binary-search.md) for the general technique.

### Limitations

Fenwick trees require **invertible operations** (sum, XOR, [modular multiplication](mathematics.md)). For min/max, lazy propagation, or persistence, use a segment tree instead.

---

## Disjoint Set Union (DSU)

**DSU** (also called Union-Find) is a data structure supporting:
- **Unite:** merge two sets
- **Find:** determine which set an element belongs to

Both operations run in nearly `O(1)` amortized. DSU is commonly used in [graph algorithms](graph-algorithms.md) (e.g. Kruskal's MST) to track connected components.

### Basic Structure

Sets are stored as trees. Each tree's **root** is the representative (leader) of the set. Array `p[i]` stores each element's parent; roots are their own parents.

```cpp
int p[maxn];
for (int i = 0; i < n; i++)
    p[i] = i;
```

**Find the root (naive):**
```cpp
int leader(int v) {
    if (p[v] == v) return v;
    else return leader(p[v]);
}
```

**Unite (naive):**
```cpp
void unite(int a, int b) {
    a = leader(a); b = leader(b);
    p[a] = b;
}
```

Worst case: `O(n)` (a degenerate "bamboo" chain).

### Optimizations

**Path compression:** On the way back from `leader`, point every node directly to the root:
```cpp
int leader(int v) {
    return (p[v] == v) ? v : p[v] = leader(p[v]);
}
```

**Rank heuristic:** Always attach the shallower tree under the deeper one:
```cpp
void unite(int a, int b) {
    a = leader(a); b = leader(b);
    if (h[a] > h[b]) swap(a, b);
    h[b] = max(h[b], h[a] + 1);
    p[a] = b;
}
```

**Weight heuristic:** Attach the smaller tree under the larger one (also gives the component size for free):
```cpp
void unite(int a, int b) {
    a = leader(a); b = leader(b);
    if (s[a] > s[b]) swap(a, b);
    s[b] += s[a];
    p[a] = b;
}
```

### Full Implementation (weight + path compression)

```cpp
int p[maxn], s[maxn];

int leader(int v) {
    return (p[v] == v) ? v : p[v] = leader(p[v]);
}

void unite(int a, int b) {
    a = leader(a); b = leader(b);
    if (s[a] > s[b]) swap(a, b);
    s[b] += s[a];
    p[a] = b;
}

void init(int n) {
    for (int i = 0; i < n; i++)
        p[i] = i, s[i] = 1;
}
```

### Complexity

- Path compression alone: `O(log n)` amortized
- Rank or weight alone: `O(log n)` worst case (tree height is bounded)
- Both together: `O(alpha(n))` amortized, where `alpha(n)` is the inverse Ackermann function — never exceeds 4 in practice

See [complexity analysis](complexity-analysis.md) for more on amortized analysis and inverse Ackermann.

---

## Segment Tree

A segment tree stores information about array intervals in a binary tree, supporting range queries and point updates in `O(log n)`.

Each node covers a range `[l, r]`. Leaf nodes correspond to single elements. Internal nodes store an aggregate (e.g., sum, min, max) over their range.

### Operations

- **Build:** `O(n)`
- **Point update:** `O(log n)`
- **Range query:** `O(log n)`

### Extensions

- **Lazy propagation:** Defer range updates — apply them only when needed. Enables range-update + range-query in `O(log n)`.
- **Persistent segment tree:** Copy-on-write nodes allow querying historical versions in `O(log n)` per update, at `O(n log n)` total memory.
- **Pointer-based segment tree:** Dynamic allocation for sparse or very large index ranges.

---

## See Also

- [Graph Algorithms](graph-algorithms.md) — DSU is used in Kruskal's MST; segment trees in HLD
- [Binary Search](binary-search.md) — binary search on Fenwick tree prefix sums
- [Mathematics](mathematics.md) — modular operations and XOR used with prefix sums and Fenwick trees
- [Coordinate Compression](coordinate-compression.md) — maps large values to array indices for these structures
- [Task Decomposition](task-decomposition.md) — 2D scanline uses segment trees

---

*Source: ru.algorithmica.org — CC BY-SA 4.0*
