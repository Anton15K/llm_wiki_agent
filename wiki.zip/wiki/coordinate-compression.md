---
title: Coordinate Compression
tags: [algorithms, sequences, compression, hashing]
---

# Coordinate Compression

It is often useful to transform a sequence of numbers (or other objects) into a range of consecutive integers — for example, to use them as indices in an array or another [data structure](data-structures.md). This is equivalent to numbering the elements of a set.

---

## Approach 1: Order of First Occurrence (O(n) via hash table)

Assigns indices in the order elements first appear in the sequence:

```cpp
vector<int> compress(vector<int> a) {
    unordered_map<int, int> m;

    for (int &x : a) {
        if (m.count(x))
            x = m[x];
        else
            m[x] = m.size();
    }

    return a;
}
```

Elements are numbered in the order of their first occurrence.

---

## Approach 2: Order-Preserving Compression (O(n log n))

If smaller elements must receive smaller indices, the problem is slightly harder. One approach: [sort](sorting-algorithms.md) the array, then use a hash table to assign indices, then remap the original array.

```cpp
vector<int> compress(vector<int> a) {
    vector<int> b = a;
    sort(b.begin(), b.end());

    unordered_map<int, int> m;

    for (int x : b)
        if (!m.count(x))
            m[x] = m.size();

    for (int &x : a)
        x = m[x];

    return a;
}
```

---

## Approach 3: Binary Search (O(n log n))

Remove duplicates from the sorted array, then use [binary search](binary-search.md) to find each element's index:

```cpp
vector<int> compress(vector<int> a) {
    vector<int> b = a;

    sort(b.begin(), b.end());
    b.erase(unique(b.begin(), b.end()), b.end());

    for (int &x : a)
        x = int(lower_bound(b.begin(), b.end(), x) - b.begin());

    return a;
}
```

Both order-preserving approaches run in **O(n log n)**. Choose whichever is more comfortable.

---

## See Also

- [Binary Search](binary-search.md) — used in approach 3 for index lookup
- [Sorting Algorithms](sorting-algorithms.md) — sorting is the first step in order-preserving compression
- [Task Decomposition](task-decomposition.md) — 2D scanline often requires coordinate compression
- [Data Structures](data-structures.md) — compression maps values to array indices for Fenwick/segment trees

---

*Source: ru.algorithmica.org — CC BY-SA 4.0*
