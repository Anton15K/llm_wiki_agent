---
title: Sorting Algorithms
tags: [algorithms, sorting, bubble-sort, selection-sort, insertion-sort, counting-sort, radix-sort]
---

# Sorting Algorithms

The sorting problem: rearrange the elements of an array in a certain order — most often non-decreasing (each element must be greater than or equal to the previous one).

```python
a = [5, 2, 1, 3, 1]
a.sort()
print(a)  # [1, 1, 2, 3, 5]
```

Although efficient sorting algorithms are implemented in the standard library of most languages, it is useful to know the underlying approaches — they can often be adapted to solve related problems.

---

## Bubble Sort

**Idea:** Make `n` passes through the array left to right, swapping adjacent elements if the first is greater than the second. Each iteration the maximum element "bubbles up" to the end of the array — hence the name.

```cpp
void bubble_sort(int *a, int n) {
    for (int k = 0; k < n; k++)
        for (int i = 0; i < n - 1; i++)
            if (a[i] > a[i + 1])
                swap(a[i], a[i + 1]);
}
```

**Correctness:** By induction, after `k` steps of bubble sort the last `k` elements are always sorted.

**Complexity:** Two nested loops, each doing `O(n)` iterations with `O(1)` work inside — total `O(n^2)`. See [complexity analysis](complexity-analysis.md) for Big-O notation.

**Exercise:** How can you adjust the loop bounds to avoid redundant work (a non-asymptotic speedup)?

---

## Selection Sort

**Idea:** On each of the `n` iterations, find the minimum of the unsorted portion and place it at its correct position. On iteration `k`, find the minimum in range `[k, n-1]` and swap it with the `k`-th element — after which the prefix `[0, k]` is sorted.

```cpp
void selection_sort(int *a, int n) {
    for (int k = 0; k < n - 1; k++)
        for (int j = k + 1; j < n; j++)
            if (a[k] > a[j])
                swap(a[j], a[k]);
}
```

**Complexity:** After each of `O(n)` outer iterations, we spend `O(n)` time finding the minimum and extending the sorted prefix — total `O(n^2)`.

---

## Insertion Sort

**Idea:** On step `k`, the prefix of length `k` is already sorted. Take the next element and swap it leftward with its left neighbor until it is greater than the element to its left. At that point the element is correctly inserted into the sorted portion.

```cpp
void insertion_sort(int *a, int n) {
    for (int k = 1; k < n; k++)
        for (int i = k; i > 0 && a[i - 1] < a[i]; i--)
            swap(a[i], a[i - 1]);
}
```

**Complexity:** Worst case is `O(n^2)` (e.g., reverse-sorted input). However, the early-stop condition in the inner loop allows better performance in favorable cases:
- If the array is already sorted: `O(n)`
- If each element is at most `k` positions away from its sorted position: `O(n*k)`

---

## Counting Sort

**Idea:** When elements belong to a small set (e.g., integers in `[1, 100]`), use a frequency array instead of comparisons.

**Algorithm:**
1. Create array `c` of size `m` (number of possible values), initialized to 0.
2. For each element in the input array, increment `c[element]`.
3. Write back: for each value `i`, write `i` exactly `c[i]` times into the output.

```cpp
void count_sort(int *a, int n) {
    int c[100] = {0};

    for (int i = 0; i < n; i++)
        c[a[i]]++;

    int k = 0;
    for (int i = 0; i < 100; i++)
        while (c[i]--)
            a[k++] = i;
}
```

**Complexity:** `O(n + m)`, where `m` is the number of possible values and `n` is the number of elements. If `m <= n`, this is effectively `O(n)` — linear!

**When to use:** When the number of distinct possible values is relatively small compared to the input size. Also used as a building block in [radix sort](#radix-sort).

---

## Radix Sort

**Idea:** Apply counting sort on large keys by processing them digit by digit (or byte by byte). For example, to sort 32-bit integers:

1. Sort stably by the lower 16 bits (key = `x mod 2^16`).
2. Sort stably by the upper 16 bits (key = `x / 2^16`).

```cpp
const int c = (1 << 16);

void radix_sort(vector<int> &a) {
    int n = (int) a.size();
    vector<int> b[c];

    // Pass 1: sort by lower 16 bits
    for (int i = 0; i < n; i++)
        b[a[i] % c].push_back(a[i]);

    int k = 0;
    for (int i = 0; i < c; i++) {
        for (size_t j = 0; j < b[i].size(); j++)
            a[k++] = b[i][j];
        b[i].clear();
    }

    // Pass 2: sort by upper 16 bits
    for (int i = 0; i < n; i++)
        b[a[i] / c].push_back(a[i]);

    k = 0;
    for (int i = 0; i < c; i++)
        for (size_t j = 0; j < b[i].size(); j++)
            a[k++] = b[i][j];
}
```

**Key property:** Each pass must use a *stable* sort (counting sort is stable), so that the relative order from the previous pass is preserved.

This approach generalizes to any type and key size.

---

## Summary

| Algorithm      | Time (worst) | Time (best) | Notes                         |
|----------------|-------------|-------------|-------------------------------|
| Bubble sort    | O(n^2)      | O(n^2)      | Simple, educational           |
| Selection sort | O(n^2)      | O(n^2)      | Minimal swaps                 |
| Insertion sort | O(n^2)      | O(n)        | Fast on nearly-sorted input   |
| Counting sort  | O(n + m)    | O(n + m)    | Requires bounded integer keys |
| Radix sort     | O(n * w)    | O(n * w)    | `w` = number of digit passes  |

---

## See Also

- [Complexity Analysis](complexity-analysis.md) — Big-O notation and analysis of sorting complexities
- [Binary Search](binary-search.md) — requires a sorted array as input
- [Coordinate Compression](coordinate-compression.md) — sorting is the first step in order-preserving compression
- [Task Decomposition](task-decomposition.md) — scanline algorithms rely on sorting events

---

*Source: ru.algorithmica.org — CC BY-SA 4.0*
