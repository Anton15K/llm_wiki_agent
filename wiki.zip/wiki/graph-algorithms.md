---
title: Graph Algorithms
tags: [graphs, dfs, bfs, dijkstra, spanning-tree, mst, topology]
---

# Graph Algorithms

---

## Graph Basics

**Definition.** A graph is a pair `G = (V, E)` where `V` is a set of **vertices** and `E` is a set of **edges** (pairs of vertices `(u, v)`).

### Terminology

| English             | Meaning                                              |
|---------------------|------------------------------------------------------|
| Vertex / node       | A point in the graph                                |
| Edge                | A connection between two vertices                   |
| Adjacent            | Two vertices connected by an edge                   |
| Degree              | Number of edges incident to a vertex                |
| Self-loop           | An edge connecting a vertex to itself               |
| Directed graph      | Each edge has a direction                           |
| Undirected graph    | Edges have no direction                             |
| Path                | A sequence of vertices connected by edges           |
| Simple path         | A path with no repeated vertices                    |
| Cycle               | A path starting and ending at the same vertex       |
| Acyclic graph       | A graph with no simple cycles                       |
| Tree                | A connected acyclic undirected graph                |
| Forest              | An acyclic undirected graph (disjoint union of trees)|
| Rooted tree         | A tree with one designated root vertex              |
| Bipartite graph     | Vertices can be split into two sets; edges only cross|
| Planar graph        | Can be drawn in a plane with no crossing edges      |
| Connected graph     | Every vertex is reachable from every other          |

**Equivalent definitions of a tree:**
- `n` vertices and `n-1` edges, no cycles
- Any two vertices are connected by exactly one path

---

## Depth-First Search (DFS)

**DFS** (depth-first search, also called Euler traversal) is a recursive graph traversal starting from a chosen vertex, visiting each vertex exactly once.

```cpp
const int maxn = 1e5;
bool used[maxn];

void dfs(int v) {
    used[v] = true;
    for (int u : g[v])
        if (!used[u])
            dfs(u);
}
```

### Entry/Exit Timestamps

Track when we enter (`tin`) and leave (`tout`) each vertex using a timer:

```cpp
int tin[maxn], tout[maxn];
int t = 0;

void dfs(int v) {
    tin[v] = t++;
    for (int u : g[v])
        if (!used[u])
            dfs(u);
    tout[v] = t;
}
```

**Useful properties of tin/tout:**
- Vertex `u` is an **ancestor** of `v` iff `tin[v] ∈ [tin[u], tout[u])` — O(1) check
- The half-open intervals `[tin[v], tout[v])` are either nested or disjoint
- `tout[v] - tin[v]` = subtree size of `v`
- Subtree vertices always form a contiguous range in `tin` order

### Applications of DFS

- Finding connected components
- Cycle detection
- Topological sort (for DAGs — process vertices by decreasing `tout`)
- Finding bridges and articulation points
- Finding strongly connected components (Tarjan's / Kosaraju's algorithm)
- 2-SAT

---

## Breadth-First Search (BFS)

BFS explores the graph level by level using a queue, finding **shortest paths** (in terms of number of edges) from the source.

```cpp
vector<int> bfs(int s) {
    vector<int> d(n, -1);
    queue<int> q;
    d[s] = 0;
    q.push(s);
    while (!q.empty()) {
        int v = q.front(); q.pop();
        for (int u : g[v]) {
            if (d[u] == -1) {
                d[u] = d[v] + 1;
                q.push(u);
            }
        }
    }
    return d; // d[v] = shortest distance from s to v, or -1 if unreachable
}
```

**Complexity:** `O(V + E)` — each vertex and edge is visited once.

---

## Dijkstra's Algorithm

Finds the **shortest paths** from a source vertex `s` to all others in a graph with **non-negative edge weights**.

### Core Idea

Maintain array `d[v]` = current best known distance from `s` to `v`. Initially `d[s] = 0`, all others `∞`. Mark vertices as "finalized" once we know their shortest path.

On each iteration, pick the unfinalized vertex `v` with the smallest `d[v]`, finalize it, then **relax** all edges out of `v`:

```
d[u] = min(d[u], d[v] + weight(v, u))
```

### Correctness

By induction: when we finalize `v`, `d[v]` is already the true shortest path. Because all edges are non-negative, no later path through an unfinalized vertex can be shorter.

### Implementation: Dense Graphs — O(n²)

```cpp
const int maxn = 1e5, inf = 1e9;
vector<pair<int,int>> g[maxn]; // g[v] = {(u, weight)}
int n;

vector<int> dijkstra(int s) {
    vector<int> d(n, inf), a(n, 0);
    d[s] = 0;
    for (int i = 0; i < n; i++) {
        int v = -1;
        for (int u = 0; u < n; u++)
            if (!a[u] && (v == -1 || d[u] < d[v]))
                v = u;
        a[v] = true;
        for (auto [u, w] : g[v])
            d[u] = min(d[u], d[v] + w);
    }
    return d;
}
```

### Implementation: Sparse Graphs — O(m log n)

Use a priority queue (min-heap) instead of a linear scan:

```cpp
vector<int> dijkstra(int s) {
    vector<int> d(n, inf);
    d[s] = 0;
    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<>> q;
    q.push({0, s});
    while (!q.empty()) {
        auto [cur_d, v] = q.top(); q.pop();
        if (cur_d > d[v]) continue; // stale entry
        for (auto [u, w] : g[v]) {
            if (d[u] > d[v] + w) {
                d[u] = d[v] + w;
                q.push({d[u], u});
            }
        }
    }
    return d;
}
```

### Path Reconstruction

Maintain parent array `p[v]` = vertex from which `v` was relaxed:

```cpp
if (d[u] > d[v] + w) {
    d[u] = d[v] + w;
    p[u] = v;
    q.push({d[u], u});
}
```

Then trace back from destination to source:

```cpp
void print_path(int v) {
    while (v != s) {
        cout << v << endl;
        v = p[v];
    }
    cout << s << endl;
}
```

Note: this prints the path in **reverse order**.

---

## Minimum Spanning Tree (MST)

A **spanning tree** of a connected graph is a tree containing all `n` vertices and exactly `n-1` edges. A **minimum spanning tree** minimizes the total edge weight.

### Safe Edge Lemma

An edge `(u, v)` is **safe** to add to an MST under construction if it is the minimum-weight edge crossing some cut (partition of vertices into two sets).

### Kruskal's Algorithm — O(m log m)

Sort all edges by weight. Greedily add each edge if it connects two different components (checked via [DSU](data-structures.md)).

```cpp
sort(edges.begin(), edges.end()); // sort by weight
for (auto [w, u, v] : edges)
    if (leader(u) != leader(v)) {
        unite(u, v);
        mst_edges.push_back({u, v, w});
    }
```

Kruskal's is a [greedy algorithm on a graphic matroid](dynamic-programming.md).

### Prim's Algorithm — O(m log n)

Grow the MST one vertex at a time. Start from any vertex, always add the cheapest edge connecting the tree to a non-tree vertex (similar structure to Dijkstra).

---

## Topological Sort

A **topological ordering** of a DAG (directed acyclic graph) is a linear ordering of vertices such that for every directed edge `(u, v)`, `u` appears before `v`.

**Algorithm:** Run DFS, record vertices in decreasing order of `tout`. Reverse the result.

```cpp
vector<int> order;

void dfs(int v) {
    used[v] = true;
    for (int u : g[v])
        if (!used[u]) dfs(u);
    order.push_back(v);
}

// call dfs on all unvisited vertices, then reverse order
```

---

## Trees — Advanced Queries

### Lowest Common Ancestor (LCA)

**Problem.** Given a rooted tree, for two vertices `u` and `v`, find their lowest common ancestor.

**Binary lifting:** Precompute `up[v][k]` = the `2^k`-th ancestor of `v`. Build in `O(n log n)`, answer each LCA query in `O(log n)`. Uses the same [binary exponentiation](mathematics.md) idea.

### Centroid Decomposition

Decompose the tree by repeatedly finding and removing centroids (vertices whose removal splits the tree into components of at most `n/2` vertices each). The decomposition tree has `O(log n)` depth. Used to efficiently solve path queries on trees.

### Heavy-Light Decomposition (HLD)

Partition tree edges into "heavy" chains such that any root-to-leaf path passes through at most `O(log n)` chains. Reduces tree path queries to range queries on a linear array (solvable with [segment trees](data-structures.md)).

---

## Matchings

A **matching** is a set of edges with no shared vertices. A **maximum matching** is the largest possible matching.

### Berge's Lemma

A matching `M` is maximum if and only if there is no **augmenting path** (a path that alternates between non-matching and matching edges, starting and ending at unmatched vertices).

### Kuhn's Algorithm (Bipartite Maximum Matching)

For bipartite graphs: greedily find augmenting paths using DFS. `O(V * E)`.

### Hall's Marriage Theorem

A bipartite graph has a perfect matching (covering all vertices on one side) if and only if for every subset `S` of left vertices, `|N(S)| >= |S|` (Hall's condition).

---

## See Also

- [Data Structures](data-structures.md) — DSU for Kruskal's, segment trees for HLD
- [Dynamic Programming](dynamic-programming.md) — Dijkstra and Kruskal's as greedy algorithms; DP on DAGs
- [Mathematics](mathematics.md) — binary lifting uses binary exponentiation
- [Complexity Analysis](complexity-analysis.md) — analysis of BFS, DFS, Dijkstra complexities

---

*Source: ru.algorithmica.org — CC BY-SA 4.0*
