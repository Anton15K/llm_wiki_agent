---
title: Binary Search
tags: [algorithms, search, binary-search]
---

# Binary Search

## The Guessing Game

**Problem.** A number `x` from 1 to 100 is hidden. You can ask yes/no questions like "Is `x` greater than N?" How many questions do you need in the worst case?

One optimal solution: ask "Is `x > 50`?", then "Is `x > 75`?" (or 25), and so on — halving the search range each time.

More formally, if the search interval is `[l, r]`, each iteration picks the midpoint `m = floor((l+r)/2)`, asks "Is `x > m`?", and updates `l = m+1` or `r = m` accordingly, until `l == r`.

```python
l, r = 1, 100

while l < r:
    m = (l + r) // 2
    resp = input(f'x > {m}? ')
    if resp == 'yes':
        l = m + 1
    else:
        r = m

print(f'x = {l}')
```

**Example session** (x = 42):
```
x > 50? no
x > 25? yes
x > 38? yes
x > 44? no
x > 41? yes
x > 43? no
x > 42? no
x = 42
```

7 questions used. In general, since the interval halves each time, the total number of steps is `O(log n)` — exactly `ceil(log2 n)` or `floor(log2 n)`. See [complexity analysis](complexity-analysis.md) for more on O-notation.

---

## Binary Search in Data Structures

**Problem.** Given an array `a`, determine whether element `x` is present.

Naively, we must examine all elements: `O(n)`. But if the array is **sorted** (see [sorting algorithms](sorting-algorithms.md)), we can use binary search to find the **lower bound** — the smallest element `>= x` — and check if it equals `x`.

```cpp
bool find(int x, int *a, int n) {
    int l = 0, r = n + 1;
    // search interval is a half-open range [l, r)
    while (l + 1 < r) {
        int m = (l + r) / 2;
        if (a[m] >= x)
            l = m;
        else
            r = m;
    }
    return (l < n && a[l] == x);
}
```

### C++ STL

```cpp
bool find(int x, vector<int> a) {
    auto it = lower_bound(a.begin(), a.end(), x);
    return (it != a.end() && *it == x);
}
```

- `lower_bound(begin, end, x)` — returns iterator to first element `>= x`
- `upper_bound(begin, end, x)` — returns iterator to first element `> x`

---

## Checking Monotone Properties

Binary search is not limited to searching for elements. It applies to any **monotone predicate** — a condition that is false for small values then true for large values (or vice versa). Finding a lower bound is a special case: we check `a[k] >= x` and want to find the first `k` where it holds.

**Other examples:**
- Find the last occurrence of `x` in a sorted array.
- Count how many times `x` appears in a sorted array.
- Find the first index where all values are even (given a prefix of odds followed by evens).

All solvable in `O(log n)`.

**Typical problem structure:** A sorted array of size `n`, answer `m` queries "is `x_i` in the array?" → `O(n + m log n)` total.

---

## Binary Search on Real Numbers

The same idea applies when the argument is a real number. We want to find where a predicate `f(x)` changes from 0 to 1.

**Example:** find `sqrt(2)` by finding where `f(x) = [x^2 >= 2]` first becomes true.

Since floating point is approximate, we either:
- Stop when `r - l < epsilon`, or
- Run a **fixed number of iterations** (100 iterations is almost always sufficient for any practical precision)

```cpp
float sqrt(float x) {
    float l = 0, r = x;
    for (int i = 0; i < 100; i++) {
        float m = (l + r) / 2;
        if (m * m < x)
            l = m;
        else
            r = m;
    }
    return l;
}
```

**How many iterations for k correct decimal digits?** Since `log10 ≈ 3 / log2`, each decimal digit takes about 3 binary search steps. So 6 decimal places requires ~18 extra steps after the interval shrinks to 1.

This generalizes to finding a zero of any continuous function for which you know points where it is negative and positive.

---

## See Also

- [Coordinate Compression](coordinate-compression.md) — approach 3 uses binary search for index lookup
- [Sorting Algorithms](sorting-algorithms.md) — binary search requires a sorted array
- [Complexity Analysis](complexity-analysis.md) — O(log n) analysis
- [Data Structures](data-structures.md) — binary search on Fenwick tree prefix sums
- [Task Decomposition](task-decomposition.md) — meet-in-the-middle uses binary search

---

*Source: ru.algorithmica.org — CC BY-SA 4.0*
