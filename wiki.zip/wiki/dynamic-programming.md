---
title: Dynamic Programming
tags: [dynamic-programming, dp, memoization, greedy, convex-hull-trick]
---

# Dynamic Programming

**Dynamic programming (DP)** is an approach to solving problems by breaking them into smaller subproblems, solving each once, and storing the results to avoid redundant work.

---

## Core Idea

Consider finding the `n`-th Fibonacci number:

```cpp
// Naive recursive — exponential time O(2^n)
int f(int n) {
    if (n == 0) return 0;
    if (n == 1) return 1;
    return f(n - 2) + f(n - 1);
}
```

This recalculates the same subproblems repeatedly. For `n > 40` it becomes too slow.

**Key insight:** Store computed values and reuse them.

```cpp
const int n = 100;
int f[n];

f[0] = 0;
f[1] = 1;

for (int i = 2; i < n; i++)
    f[i] = f[i - 2] + f[i - 1];
```

This runs in `O(n)`. (For large `n`, use [modular arithmetic](mathematics.md) to avoid overflow.) The Fibonacci recurrence can also be solved in `O(log n)` via [matrix exponentiation](mathematics.md).

---

## The Five DP Questions

To solve any DP problem, answer these questions:

1. **What does the array store?** *(usually the most critical question)*
2. **How to initialize the base cases?**
3. **In what order to fill the array?** *(usually left to right)*
4. **What recurrence computes each element?**
5. **Where in the array is the final answer?**

---

## Common DP Patterns

### Interval DP (DP on Subarrays)

State `dp[l][r]` represents the answer for subarray `[l, r]`.

**Example:** Optimal matrix chain multiplication, optimal parenthesization.

Transition splits the interval at some index `k`:
```
dp[l][r] = min over k in [l, r-1] of { dp[l][k] + dp[k+1][r] + cost(l, r) }
```

Fill in order of increasing interval length.

### Memoization (Lazy DP)

Instead of filling bottom-up, compute top-down and cache results:

```cpp
map<int, int> memo;

int solve(int n) {
    if (n <= 1) return n;
    if (memo.count(n)) return memo[n];
    return memo[n] = solve(n-1) + solve(n-2);
}
```

Useful when not all subproblems are needed, or when the state space is sparse.

---

## Combinatorial Optimization

### Greedy Algorithms

A **greedy algorithm** makes the locally optimal choice at each step with the hope that it leads to a globally optimal solution.

Greedy works when the **greedy choice property** holds: a locally optimal choice is always part of some globally optimal solution.

**Classic examples:**
- Activity selection (always pick the earliest-ending activity)
- Huffman encoding (always merge the two cheapest nodes)
- [Dijkstra's shortest path](graph-algorithms.md) (always expand the closest unvisited vertex)

### Matroids

A **matroid** is an abstract structure that guarantees greedy is optimal. If the problem can be modeled as finding a maximum-weight independent set in a matroid, greedy (by decreasing weight) gives the optimal answer.

**Graphic matroid:** The independent sets are the forests of a graph. [Kruskal's MST algorithm](graph-algorithms.md) is greedy on this matroid.

### Simulated Annealing

A probabilistic optimization method that occasionally accepts worse solutions to escape local optima. Temperature decreases over time, reducing acceptance of bad moves. Used when exact DP is too slow and greedy is insufficient.

---

## Layer Optimizations

When the DP has the form `f[i][j] = min over k < i { f[k][j-1] + cost(k, i) }`, special structure can reduce `O(n^2)` per layer to `O(n log n)` or `O(n)`.

### Divide and Conquer Optimization

**Condition:** The optimal split point `opt(i, j)` is monotone:
```
opt(i, j) <= opt(i+1, j)
```

Use divide and conquer on `i`, sharing the search range for `opt`:
- Recursively solve the left half using `[lo, mid]` as the search range
- Recursively solve the right half using `[mid, hi]` as the search range

**Complexity:** `O(n log n)` per DP layer instead of `O(n^2)`. See [complexity analysis](complexity-analysis.md) for the Master Theorem applied to such recurrences.

### Knuth's Optimization

**Condition:** Cost function `w(i, j)` satisfies the **quadrangle inequality**:
```
w(a, c) + w(b, d) <= w(a, d) + w(b, c)   for a <= b <= c <= d
```

Then `opt(i, j-1) <= opt(i, j) <= opt(i+1, j)` (monotonicity holds).

**Complexity:** `O(n^2)` total for a 2D DP that would otherwise be `O(n^3)`.

### Convex Hull Trick (CHT)

**When to use:** DP recurrence of the form:
```
f[i][j] = min over k < i { f[k][j-1] + a_k * x_i + b_k }
```
where `a_k` and `b_k` depend only on `k`, and `x_i` depends only on `i`.

**Idea:** Each previous state `k` defines a **line** `y = b_k * x + a_k`. The DP query for `i` is: find the minimum line value at `x = x_i`. Maintain a **lower convex hull** of these lines and query it. See also [convex hulls in geometry](strings-and-geometry.md).

```cpp
struct line {
    int k, b;
    int get(int x) { return k * x + b; }
};

vector<line> lines;
vector<int> dots; // x-coordinates of hull breakpoints

int cross(line a, line b) { // intersection x-coordinate (a.k > b.k)
    int x = (b.b - a.b) / (a.k - b.k);
    if (b.b < a.b) x--;
    return x;
}

void add(line cur) {
    while (lines.size() && lines.back().get(dots.back()) > cur.get(dots.back())) {
        lines.pop_back(); dots.pop_back();
    }
    if (lines.empty()) dots.push_back(-1e9);
    else dots.push_back(cross(lines.back(), cur));
    lines.push_back(cur);
}

int get(int x) {
    int pos = lower_bound(dots.begin(), dots.end(), x) - dots.begin() - 1;
    return lines[pos].get(x);
}
```

- If queries are **monotone** (x_i increases): use a pointer instead of [binary search](binary-search.md) → `O(n)` total
- Otherwise: use binary search → `O(n log n)` total

### Lagrangian Relaxation (Aliens / Lambda Optimization)

**When to use:** DP with a constraint "use exactly `k` operations." Binary search on a penalty `lambda` added per operation, converting it to an unconstrained DP.

---

## Game Theory

### Nim

**Game:** Players alternately remove stones from piles. The player who takes the last stone wins.

**Key theorem:** The first player wins if and only if the XOR of all pile sizes is non-zero.

This extends to all **impartial games** via the **Sprague-Grundy theorem**: every position has a Grundy number (nimber), and composite games add via XOR.

---

## See Also

- [Graph Algorithms](graph-algorithms.md) — Dijkstra and Kruskal's as greedy algorithms
- [Mathematics](mathematics.md) — modular arithmetic, matrix exponentiation for linear recurrences
- [Strings and Geometry](strings-and-geometry.md) — convex hulls used in CHT
- [Binary Search](binary-search.md) — used in CHT queries and Lagrangian relaxation
- [Complexity Analysis](complexity-analysis.md) — Master Theorem for divide-and-conquer DP

---

*Source: ru.algorithmica.org — CC BY-SA 4.0*
